package com.quintic.ble.paibloks;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
//import android.os.Vibrator;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import com.quintic.libqpp.QppApi;
import com.quintic.libqpp.iQppCallback;
import android.widget.SeekBar.OnSeekBarChangeListener;
import csh.tiro.cc.*;


@SuppressLint("ClickableViewAccessibility")
public class QppActivity extends Activity {
	protected static final String TAG = QppActivity.class.getSimpleName();
	private BluetoothManager mBluetoothManager=null;
	private static BluetoothAdapter mBluetoothAdapter=null;
	public static BluetoothGatt mBluetoothGatt=null;
	
	public static final String EXTRAS_DEVICE_NAME = "deviceName";
	public static final String EXTRAS_DEVICE_ADDRESS = "deviceAddress";
	
	
	private boolean dataRecvFlag=false;
	private String deviceName;
	private String deviceAddress;

	/** connection state */
	private boolean mConnected = false; 
	/** scan all Service ?*/
	private boolean isInitialize = false;
	
	
	/// public 
	private TextView textDeviceName;
	private TextView textDeviceAddress;
	
	/// qpp start
	protected static String uuidQppService = "0000fee9-0000-1000-8000-00805f9b34fb";
	protected static String uuidQppCharWrite = "d44bc439-abfd-45a2-b575-925416129600";

	protected boolean qppConfirmFlag;

	private Button button_move_motor_z ;
	private Button button_move_motor_f ; 
	private Button button_move_motor_t ; 
	private Button button_LR_motor_z ; 
	private Button button_LR_motor_f ; 
	private Button button_LR_motor_t ; 
	private Button button_motor_1_z ; 
	private Button button_motor_1_f ; 
	private Button button_motor_1_t ; 
	private Button button_motor_2_z ;
	private Button button_motor_2_f ;
	private Button button_motor_2_t ;
	
	private Button button_play ; 
	private Button button_stop ; 
	private Button button_zt ; 
	private Button button_jx ; 
	private Button button_get_v;
	
	private Button button_set_bat ;
	private Button button_fun_reset;
	private Button button_sys_reset;
	
	
	private SeekBar seekbar_r ; 
	private SeekBar seekbar_g ;
	private SeekBar seekbar_b ; 
	private SeekBar seekbar_l ;
	private SeekBar seekbar_v ; 
	
	private Spinner sp1 ; 
	//private Spinner sp_bat;
	
	private TextView bat_view ; 
	private TextView bat_flag ;
	private TextView Version_s ;
	private TextView Version_h ;
	
	private TextView rgb_r_v ; 
	private TextView rgb_g_v ; 
	private TextView rgb_b_v ;
	private TextView rgb_l_v ; 
	private TextView rgb_v_v ; 
	
	private int led_D_r = 0 ; 
	private int led_D_g = 0 ; 
	private int led_D_b = 0 ; //车头 底盘颜色
	private int led_D_l = 255 ; 
	
	private aes BleKeyIns = new aes();
	private boolean initialed = false ;
	
	private boolean qppSendDataState = false;	//连续发送标志
	private int send_data_end = 0 ; 
	
	private byte qppDataSend[] = {0x55,(byte)0xaa,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; // 发送数据的数组
	


	/*******************************************************************************************************************************
	 * 初始化函数 
	 ******************************************************************************************************************************/
	private boolean initialize() 
	{
	    // For API level 18 and above, get a reference to BluetoothAdapter through BluetoothManager.
	    if (mBluetoothManager == null) 
	    {
			mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
			if (mBluetoothManager == null) 
			{
			    Log.e(TAG, "Unable to initialize BluetoothManager.");
			    return false;
			}
	    }	        
	    mBluetoothAdapter = mBluetoothManager.getAdapter();
	    if (mBluetoothAdapter == null) 
	    {
			Log.e(TAG, "Unable to obtain a BluetoothAdapter.");
			return false;
	    }		
	    return true;
	}
	
	/*******************************************************************************************************************************
	 * 删除线程函数
	 ******************************************************************************************************************************/
	private void clearHandler(Handler handler,Runnable runner)
	{
	    if(handler!=null){
		handler.removeCallbacks(runner);
		handler=null;
	    }
	}
	
	/*******************************************************************************************************************************
	 * 创建发送 数据线程 与 运行线程
	 ******************************************************************************************************************************/
	private Handler handlersend = new Handler( );// 发送数据的线程
	final Runnable runnableSend = new Runnable( ) 	
	{
		private void QppSendNextData() 
		{
			if(initialed == false)
			{
				return ;
			}
			
			int randdat = (int)(Math.random()*65535) ;
			qppDataSend[11] = (byte)((randdat>>1) & 0xff) ;
			qppDataSend[12] = (byte)((randdat>>2) & 0xff) ;
			qppDataSend[13] = (byte)((randdat>>3) & 0xff) ;
			qppDataSend[14] = (byte)((randdat>>4) & 0xff) ;
			qppDataSend[15] = (byte)((randdat>>5) & 0xff) ;
			byte[] qppDataSen = new byte[qppDataSend.length];
			BleKeyIns.cipher(qppDataSend, qppDataSen);
			
			if(!QppApi.qppSendData(mBluetoothGatt, qppDataSen))
		    {
		    	Log.e(TAG,"send data failed");
		    	return;
		    }
		    
		}    	
		public void run ( ) 
		{
			QppSendNextData();
        }
	};
	
	private void setQppNotify(final byte[] b) 
	{
        runOnUiThread(new Runnable() 
        {
        	
        	byte[] t = b ;
            @Override
            public void run() 
            {	
            	if(t.length == 16)
            	{
            		if((t[0] == (byte)0x55)&&(t[1] == (byte)0xaa))
            		{
            			if((t[2] == 'G')&&(t[3] == (byte)0xa1))
            			{//获取电量 & 电量状态
            				if(((t[2]+t[3]+t[4]+t[5]+t[6]+t[7]+t[8]+t[9]+t[10])&0xff)==0)
            				{	//此处是电量信号
            					bat_view.setText("电量:"+t[9]+" %");
            					if(t[7] != 0) bat_flag.setText("充电中");
            					else          bat_flag.setText("未充电");
            				}
            				//Log.d("lv", "lvxian124 =:"+t[0]+","+t[1]+","+(char)t[2]+","+t[3]+","+t[4]+","+t[5]+","+t[6]+","+t[7]+","+t[8]+","+t[9]+","+t[10]);
            				//Log.d("lv", "lvxian124 bat ="+(int)t[7]+","+(int)t[9]);
            			}
            			else if((t[2] == 'G')&&(t[3] == (byte)0xa2))
            			{ //此处是版本号好获取
            				if(((t[2]+t[3]+t[4]+t[5]+t[6]+t[7]+t[8]+t[9]+t[10])&0xff)==0)
            				{
            					int verss = (((int)t[9])&0xff) + ((((int)t[8])<<8)&0xff) + ((((int)t[7])<<8)&0xff) ;
            					Version_s.setText("软件:"+verss);
            					Version_h.setText("硬件:"+t[6]);
            				}
            				//Log.d("lv", "lvxian124 =:"+t[0]+","+t[1]+","+(char)t[2]+","+t[3]+","+t[4]+","+t[5]+","+t[6]+","+t[7]+","+t[8]+","+t[9]+","+t[10]);
        					//Log.d("lv", "lvxian124 v ="+(int)t[6]+","+(int)t[9]);
            			}
            			else
            			{// 发送数据后反馈回来的 ACK 数据
            				Log.d("lv", "lvxianack =:"+t[0]+","+t[1]+","+(char)t[2]+","+t[3]+","+t[4]+","+t[5]+","+t[6]+","+t[7]+","+t[8]+","+t[9]+","+t[10]);
            			}
            		}
            	}
            }
        });        
    }
	
	/*******************************************************************************************************************************
	 * 获取 开发板发过来的数据
	 ******************************************************************************************************************************/
	private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback()
	{
		//-----------------------------------------------
		//检查蓝牙连接状态
		@Override
		public void onConnectionStateChange(BluetoothGatt gatt, int status,int newState) 
		{
			Log.i(TAG, "onConnectionStateChange : "+status+"  newState : "+newState);
			if(newState == BluetoothProfile.STATE_CONNECTED)			//如果是连接状态
			{			
			    mBluetoothGatt.discoverServices();			    		//则扫描 服务器 
			    mConnected = true;			    			  			//开启连接标志    			    
			}
			else if(newState== BluetoothProfile.STATE_DISCONNECTED)		//如果是断开状态 
			{
			    mConnected = false;										//关闭连接标志
			    clearHandler(handlerQppDataRate,runnableQppDataRate);	//关闭向开发板读取数据 线程
			    clearHandler(handlersend,runnableSend);					//关闭向开发板发送数据 线程
			    dataRecvFlag=false;
			    if(qppSendDataState)	qppSendDataState=false;			//发送标志清理
			    close();
			}
	        invalidateOptionsMenu();  			
		}	
		
		//-----------------------------------------------
		//判断是否连接到 开发板
		@Override
		public void onServicesDiscovered(BluetoothGatt gatt, int status) {		    
		    if(QppApi.qppEnable(mBluetoothGatt, uuidQppService, uuidQppCharWrite))
		    {	
		    	isInitialize = true;	//连接到开发板
		    }
		    else
		    {
		    	isInitialize = false;	//没有连接到开发板
		    }
		}			
		
		//-----------------------------------------------
		//Qpp API 更新 特征状态
		@Override
		public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) 
		{       			          	
			QppApi.updateValueForNotification(gatt, characteristic);        	            	    
		}		
		//-----------------------------------------------
		// 设置 QPP 下一个通知
		@Override
		public void onDescriptorWrite(BluetoothGatt gatt,BluetoothGattDescriptor descriptor, int status) 
		{
		    Log.w(TAG,"onDescriptorWrite");
		    QppApi.setQppNextNotify(gatt, true);	
		}
		//-----------------------------------------------
		// 发送数据，线程延时
		@Override
		public void onCharacteristicWrite(BluetoothGatt gatt,BluetoothGattCharacteristic characteristic, int status) 
		{
														//发送数据为 真
		    if(status == BluetoothGatt.GATT_SUCCESS && qppSendDataState)
		    {
			/*This is a workaround,20140819,xiesc: it paused with unknown reason on android 4.4.3 
			 */
				if(handlersend!=null && runnableSend!=null)
				{
					//发送完成
					Log.d("lv", "lvxian = send data end");
				}
		    }
		    else
		    {
			Log.e(TAG,"Send failed!!!!");
		    }
		} 			
	};	
	
	
	/*******************************************************************************************************************************
	 * 检查连接 开发板是否成功函数
	 ******************************************************************************************************************************/
	public boolean connect(final String address) 
	{
	    if (mBluetoothAdapter == null || address == null) 
	    {
	    	Log.w("Qn Dbg", "BluetoothAdapter not initialized or unspecified address.");
	    	return false;
	    }
	    final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);	// 获得 开发板地址
	    if (device == null) 
	    {
	    	Log.w(TAG, "Device not found.  Unable to connect.");
	    	return false;
	    }
	    //setting the autoConnect parameter to false.
	    //设置自动连接参数设置为false
	    mBluetoothGatt = device.connectGatt(this, false, mGattCallback);
	        
	    Log.d(TAG, "Trying to create a new connection. Gatt: " + mBluetoothGatt);
	    return true;
	}
	/*******************************************************************************************************************************
	 * 断开 开发板蓝牙函数
	 ******************************************************************************************************************************/
	public void disconnect() 
	{
	    if (mBluetoothAdapter == null || mBluetoothGatt == null) 
	    {
	            Log.w("Qn Dbg", "BluetoothAdapter not initialized");
	            return;
	    }       	        
	    mBluetoothGatt.disconnect();
	}
	/*******************************************************************************************************************************
	 * 关闭 蓝牙 GATT函数
	 ******************************************************************************************************************************/    
	public void close() {
	    if (mBluetoothGatt != null) {
		    mBluetoothGatt.close();
		    mBluetoothGatt = null;
	    }
	}
	/*******************************************************************************************************************************
	 * 创建接收  数据线程 与 运行线程
	 ******************************************************************************************************************************/ 
	final Handler handlerQppDataRate = new Handler( );
	final Runnable runnableQppDataRate = new Runnable( ) {
        public void run ( ) 
        {
        	dataRecvFlag=false;
        }
	};
  
	
	
	
	
	/*******************************************************************************************************************************
	 * 初始化界面，创建 Activity 时调用
	 ******************************************************************************************************************************/
    @Override
    protected void onCreate(Bundle savedInstanceState) 
    {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_qpp); 
		getActionBar().setDisplayHomeAsUpEnabled(true);		
			
		textDeviceName = (TextView)findViewById(R.id.text_device_name);
		textDeviceAddress = (TextView)findViewById(R.id.text_device_address);
		
		deviceName = getIntent().getExtras().getString(EXTRAS_DEVICE_NAME);
		deviceAddress =getIntent().getExtras().getString(EXTRAS_DEVICE_ADDRESS);		
		textDeviceName.setText(deviceName);
		textDeviceAddress.setText(deviceAddress);
		
		bat_view =(TextView)findViewById(R.id.textView2) ; 
		bat_flag =(TextView)findViewById(R.id.textView1) ;
		
		Version_s=(TextView)findViewById(R.id.textView18);
		Version_h=(TextView)findViewById(R.id.textView17);
		
		
		rgb_r_v =(TextView)findViewById(R.id.textView3) ; 
		rgb_g_v =(TextView)findViewById(R.id.textView4) ; 
		rgb_b_v =(TextView)findViewById(R.id.textView5) ; 
		rgb_l_v =(TextView)findViewById(R.id.textView6) ;
		rgb_v_v =(TextView)findViewById(R.id.textView16) ;
		
		seekbar_r = (SeekBar)findViewById(R.id.seekBar1);
		seekbar_g = (SeekBar)findViewById(R.id.seekBar2);
		seekbar_b = (SeekBar)findViewById(R.id.seekBar3);
		seekbar_l = (SeekBar)findViewById(R.id.seekBar4);
		seekbar_v = (SeekBar)findViewById(R.id.seekBar5);
		
		seekbar_r.setMax(255);
		seekbar_g.setMax(255);
		seekbar_b.setMax(255);
		seekbar_l.setMax(255);
		seekbar_l.setProgress(255);
		seekbar_v.setMax(255);
		seekbar_v.setProgress(255);
		
		
		button_move_motor_z = (Button)findViewById(R.id.M1Z) ;
		button_move_motor_f = (Button)findViewById(R.id.M1F) ; 
		button_move_motor_t = (Button)findViewById(R.id.button1) ; 
		button_LR_motor_z = (Button)findViewById(R.id.M2Z) ; 
		button_LR_motor_f = (Button)findViewById(R.id.M2F) ; 
		button_LR_motor_t = (Button)findViewById(R.id.button2) ; 
		button_motor_1_z = (Button)findViewById(R.id.M3Z) ; 
		button_motor_1_f = (Button)findViewById(R.id.M3F) ; 
		button_motor_1_t = (Button)findViewById(R.id.button7) ; 
		button_motor_2_z = (Button)findViewById(R.id.M4Z) ;
		button_motor_2_f = (Button)findViewById(R.id.M4F) ;
		button_motor_2_t = (Button)findViewById(R.id.button8) ;
		
		button_play = (Button)findViewById(R.id.button3) ; 
		button_stop = (Button)findViewById(R.id.button4) ; 
		button_zt = (Button)findViewById(R.id.button5) ; 
		button_jx = (Button)findViewById(R.id.button6); 
		button_set_bat = (Button)findViewById(R.id.button9);
		button_get_v = (Button)findViewById(R.id.button12);
		button_fun_reset=(Button)findViewById(R.id.button10);
		button_sys_reset=(Button)findViewById(R.id.button11);

		
		BleKeyIns.keyExpansionDefault();
		sp1 = (Spinner)findViewById(R.id.spinner1);
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.sound_qms,android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		sp1.setAdapter(adapter);
		
//		sp_bat = (Spinner)findViewById(R.id.spinner_time);
//		ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this, R.array.bat_delay,android.R.layout.simple_spinner_item);
//		adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//		sp_bat.setAdapter(adapter1);
		
		
		bat_view = (TextView)findViewById(R.id.textView2);
		bat_view.setText("电量: 70 %");
		

		
		if (!initialize()) 	//初始化蓝牙
		{
		    Log.e(TAG, "Unable to initialize Bluetooth");
		    finish();
		}	
		
		
		
		
		//====================================================================
		// 设置回调函数，实现读取 开发板发过来的数据
		QppApi.setCallback(new iQppCallback()
		{		
		    @Override
		    public void onQppReceiveData(BluetoothGatt mBluetoothGatt, String qppUUIDForNotifyChar, byte[] qppData) 
		    {
		    	
		    	//Log.d("lv", "lvxian 1");
		    	if(qppData.length == 12)
		    	{
		    		initialed = true ; 
		    	}
		    
				if(!dataRecvFlag)
				{
				    handlerQppDataRate.postDelayed(runnableQppDataRate,1000);
				    dataRecvFlag=true;
				} 
				
				if(qppSendDataState == false) 
				{
					qppSendDataState = true ;
					send_data_end = 0 ; 
				}
				
				if((qppData.length == 16) && initialed)
				{
					byte[] t = new byte[qppData.length];
			
					BleKeyIns.invCipher(qppData, t);
					setQppNotify(t);
				}
				
		    }
		}); 
	
	
		
		seekbar_r.setOnSeekBarChangeListener(seekfun);
		seekbar_g.setOnSeekBarChangeListener(seekfun);
		seekbar_b.setOnSeekBarChangeListener(seekfun);
		seekbar_l.setOnSeekBarChangeListener(seekfun);
		seekbar_v.setOnSeekBarChangeListener(seekfun);
		
		
			//setOnTouchListener
		button_move_motor_z.setOnTouchListener(button_key) ;
		button_move_motor_f.setOnTouchListener(button_key)  ; 
		button_move_motor_t.setOnTouchListener(button_key)  ; 
		button_LR_motor_z.setOnTouchListener(button_key)  ; 
		button_LR_motor_f.setOnTouchListener(button_key)  ; 
		button_LR_motor_t.setOnTouchListener(button_key)  ; 
		button_motor_1_z.setOnTouchListener(button_key)  ; 
		button_motor_1_f.setOnTouchListener(button_key)  ; 
		button_motor_1_t.setOnTouchListener(button_key)  ; 
		button_motor_2_z.setOnTouchListener(button_key)  ;
		button_motor_2_f.setOnTouchListener(button_key)  ;
		button_motor_2_t.setOnTouchListener(button_key)  ;
		
		button_play.setOnTouchListener(button_key)  ; 
		button_stop.setOnTouchListener(button_key)  ; 
		button_zt.setOnTouchListener(button_key)  ; 
		button_jx.setOnTouchListener(button_key)  ; 
		button_set_bat.setOnTouchListener(button_key);
		button_fun_reset.setOnTouchListener(button_key);
		button_sys_reset.setOnTouchListener(button_key);
		button_get_v.setOnTouchListener(button_key);
		
		
		
	}		
    
    private OnTouchListener button_key = new OnTouchListener()
	{
		@Override
		public boolean onTouch(View arg0, MotionEvent arg1) {
			// TODO Auto-generated method stub
			if(mConnected == false || isInitialize == false) return false ; 
			switch(arg0.getId())
			{
			case R.id.button12: //获取版本号
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					//int qmm = sp_bat.getSelectedItemPosition();
					qppDataSend[2] = 'G';
					qppDataSend[3] = (byte)0xa2 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = 0 ;
					qppDataSend[9] = 0 ;
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button9:	//获取电量
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					//int qmm = sp_bat.getSelectedItemPosition();
					qppDataSend[2] = 'G';
					qppDataSend[3] = (byte)0xa1 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = 0 ;
					qppDataSend[9] = 0 ;
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button10: //功能复位
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'R';
					qppDataSend[3] = (byte)0xa2 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 2 ;
					qppDataSend[7] = 4 ; 
					qppDataSend[8] = 6 ;
					qppDataSend[9] = 8 ;
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian fun reset");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button11:// 系统复位
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'R';
					qppDataSend[3] = (byte)0xa1 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 1 ;
					qppDataSend[7] = 3 ; 
					qppDataSend[8] = 5 ;
					qppDataSend[9] = 7 ;
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian System reset");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M1Z://button_move_motor_z = (Button)findViewById(R.id.M1Z) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa1 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xaa ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m1z");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M1F://button_move_motor_f = (Button)findViewById(R.id.M1F) ; 
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa1 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0x55 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m1f");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button1://button_move_motor_t = (Button)findViewById(R.id.button1) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa1 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xa5 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m1s");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M2Z://button_LR_motor_z = (Button)findViewById(R.id.M2Z) ; 
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa2 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xaa ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m2z");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M2F://button_LR_motor_f = (Button)findViewById(R.id.M2F) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa2 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0x55 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m2f");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button2://button_LR_motor_t = (Button)findViewById(R.id.button2) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa2 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xa5 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m2s");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M3Z://button_motor_1_z = (Button)findViewById(R.id.M3Z) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa3 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xaa ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m3z");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M3F://button_motor_1_f = (Button)findViewById(R.id.M3F) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa3 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0x55 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m3f");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button7://button_motor_1_t = (Button)findViewById(R.id.button7) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa3 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xa5 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m3s");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M4Z://button_motor_2_z = (Button)findViewById(R.id.M4Z) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa4 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xaa ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m4z");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.M4F://button_motor_2_f = (Button)findViewById(R.id.M4F) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa4 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0x55 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m4f");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button8://button_motor_2_t = (Button)findViewById(R.id.button8) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					qppDataSend[2] = 'M';
					qppDataSend[3] = (byte)0xa4 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = (byte)0xa5 ;
					qppDataSend[9] = (byte)seekbar_v.getProgress();
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian m4s");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button3://button_play = (Button)findViewById(R.id.button3) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					int qm = sp1.getSelectedItemPosition();
					qppDataSend[2] = 'S';
					qppDataSend[3] = (byte)0xa1 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = 0 ;
					qppDataSend[9] = (byte)((qm+1)&0xff);
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian play");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button4://button_stop = (Button)findViewById(R.id.button4) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					int qm = sp1.getSelectedItemPosition();
					qppDataSend[2] = 'S';
					qppDataSend[3] = (byte)0xa2 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = 0 ;
					qppDataSend[9] = (byte)((qm+1)&0xff);
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian stop");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button5://button_zt = (Button)findViewById(R.id.button5) ;
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					int qm = sp1.getSelectedItemPosition();
					qppDataSend[2] = 'S';
					qppDataSend[3] = (byte)0xa3 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = 0 ;
					qppDataSend[9] = (byte)((qm+1)&0xff);
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256)); 
					Log.d("lv", "lvxian zt");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			case R.id.button6://button_jx = (Button)findViewById(R.id.button6);
				if(arg1.getAction() == MotionEvent.ACTION_DOWN)
				{
					int qm = sp1.getSelectedItemPosition();
					qppDataSend[2] = 'S';
					qppDataSend[3] = (byte)0xa4 ;
					qppDataSend[4] = 0 ;
					qppDataSend[5] = 4 ; 
					qppDataSend[6] = 0 ;
					qppDataSend[7] = 0 ; 
					qppDataSend[8] = 0 ;
					qppDataSend[9] = (byte)((qm+1)&0xff);
					qppDataSend[10]= (byte)(256-((qppDataSend[2] +
												  qppDataSend[3] +
												  qppDataSend[4] +
												  qppDataSend[5] +
												  qppDataSend[6] +
												  qppDataSend[7] +
												  qppDataSend[8] +
												  qppDataSend[9])%256));
					Log.d("lv", "lvxian jx");
					if(send_data_end == 0)
					{ 
						handlersend.post(runnableSend); 
					}
				}
				break;
			
			}
			return false;
		}
		
	};
	
	
	private OnSeekBarChangeListener seekfun = new OnSeekBarChangeListener()
	{
		@Override
		public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
			// TODO Auto-generated method stub
			switch(arg0.getId())
			{
				case R.id.seekBar1:
				case R.id.seekBar2:	
				case R.id.seekBar3:	
				case R.id.seekBar4:	
				case R.id.seekBar5:	
					led_D_r = seekbar_r.getProgress() ;
					led_D_g = seekbar_g.getProgress() ;
					led_D_b = seekbar_b.getProgress() ;
					led_D_l = seekbar_l.getProgress() ;
					
					rgb_r_v.setText(""+led_D_r);
					rgb_g_v.setText(""+led_D_g);
					rgb_b_v.setText(""+led_D_b);
					rgb_l_v.setText(""+led_D_l);
					rgb_v_v.setText(""+seekbar_v.getProgress());
					break;
			}
		}

		@Override
		public void onStartTrackingTouch(SeekBar arg0) {
			// TODO Auto-generated method stub
			
		}

		
		@Override
		public void onStopTrackingTouch(SeekBar arg0) {
			// TODO Auto-generated method stub
			switch(arg0.getId())
			{
			case R.id.seekBar1://r
			case R.id.seekBar2://g
			case R.id.seekBar3://b
			case R.id.seekBar4://l
				qppDataSend[2] = 'L';
				qppDataSend[3] = (byte)0xa1 ;
				qppDataSend[4] = 0 ;
				qppDataSend[5] = 4 ; 
				qppDataSend[6] = (byte)led_D_r ; 
				qppDataSend[7] = (byte)led_D_g ;
				qppDataSend[8] = (byte)led_D_b ;
				qppDataSend[9] = (byte)led_D_l ; 
				qppDataSend[10]= (byte)(256-((qppDataSend[2] +
											  qppDataSend[3] +
											  qppDataSend[4] +
											  qppDataSend[5] +
											  qppDataSend[6] +
											  qppDataSend[7] +
											  qppDataSend[8] +
											  qppDataSend[9])%256));
				
				
				Log.d("lv", "lvxian LED");
				if(send_data_end == 0)
				{ 
					handlersend.post(runnableSend); 
				}
				break;
			case R.id.seekBar5://v
				
				break;
			}
			
		}
		
	};
    

    /*******************************************************************************************************************************
	 * 创建菜单选项
	 ******************************************************************************************************************************/
	@Override	
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.qpp, menu);
		
		if (mConnected) 
		{
			menu.findItem(R.id.menu_connect).setVisible(false);
			menu.findItem(R.id.menu_disconnect).setVisible(true);
			qppSendDataState = false ; 
		} 
		else 
		{
			menu.findItem(R.id.menu_connect).setVisible(true);
			menu.findItem(R.id.menu_disconnect).setVisible(false);
			qppSendDataState = false ; 
		}
		return true;
	}
	
	/*******************************************************************************************************************************
	 * 在选项中 选择
	 ******************************************************************************************************************************/
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
		switch (item.getItemId()) 
		{
		case R.id.menu_connect:
			connect(deviceAddress);
			qppSendDataState = false ;
			return true;
		case R.id.menu_disconnect:
			disconnect();
			qppSendDataState = true ; 
			return true;
		case android.R.id.home:
			onBackPressed();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}	
	
	/*******************************************************************************************************************************
	 * 用户交互时被调用 
	 ******************************************************************************************************************************/
	@Override
	protected void onResume() {
		super.onResume();
		if(!mConnected)
		{
		    invalidateOptionsMenu();	//初始化菜单
		    connect(deviceAddress);		//连接蓝牙地址
	    }        
		qppSendDataState = false ; 
	}	  
	
	/*******************************************************************************************************************************
	 *  Activity 交换时保持数据 用
	 ******************************************************************************************************************************/
	@Override
	protected void onPause() {
		super.onPause();
	}

	/*******************************************************************************************************************************
	 *  Activity 销毁时调用
	 ******************************************************************************************************************************/
	@Override
	protected void onDestroy() {
		super.onDestroy();
		dataRecvFlag = false ; 
		mConnected = false; 
		isInitialize = false ; 
		qppSendDataState = false ; 
		clearHandler(handlerQppDataRate,runnableQppDataRate);
		clearHandler(handlersend,runnableSend);		
		close();
	}
}
